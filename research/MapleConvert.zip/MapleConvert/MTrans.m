(* :Title: MTrans.m *)

(* :Author: Chris Willett, Lars Hohmuth *)

(* :Date: August 12, 1997 *)

(* :Summary:  This package is designed to facilitate the 
	translation of Maple into Mathematica. *)

(* :Package Version: 2.10 *)

(* :Maple Version: Maple V Release 4 *)

(* :Mathematica Version: 3.0.0 Windows95 *)

BeginPackage["`convert`"]

MapleToMathematica::usage=
  "MapleToMathematica[string] converts the Maple input string to its \
Mathematica equivalent."
		

StandardDictionary::usage=
  "StandardDictionary is a list of the Maple functions whose equivalent is \
built in function in Mathematica."
		
LaplaceTransformDictionary::usage="LaplaceTransformDictionary 
is a list of the functions in the package LaplaceTransform
which are targets of translation."

DescriptiveStatisticsDictionary::usage="DescriptiveStatisticsDictionary 
is a list of the functions in the package 
DescriptiveStatistics which are targets of translation."

DiscreteDistributionsDictionary::usage="DiscreteDistributionsDictionary 
is a list of the functions in the package 
DiscreteDistributions which are targets of translation."

ContinuousDistributionsDictionary::usage="ContinuousDistributionsDictionary 
is a list of the functions in the package 
ContinuousDistributions which are targets of translation."

MultiDescriptiveStatisticsDictionary::usage="
MultiDescriptiveStatisticsDictionary 
is a list of the functions in the package 
MultiDescriptiveStatistics which are targets of translation."

ConvertWorkSheet::usage="ConvertWorkSheet[filename] opens the 
Maple WorkSheet filename and processes it using 
MapleToMathematica into a Mathematica Notebook."

GetFileName::usage="GetFileName is a workaround for opening the
Standard File Dialog box, it is obsolete in 3.5 and higher."

EvaluateExpression::usage="ConvertExpression converts Maple commands into Mathematica input";

ConvertExpression::usage="ConvertExpression converts Maple commands into a Mathematica string containing the equivalent Mathematica input";

Begin["`Private`"]

StandardDictionary={"sin","cos","tan","diff","evalf","evalhf", "int","abs",
    "argument","binomial","ceil","conjugate","erf","erfc","exp","factorial",
    "floor","ln","max","min","round","signum","sqrt","trunc","cot","sec",
    "csc","sinh","cosh","tanh","sech","csch","coth","arcsin","arccos",
    "arctan","arccot","arcsec","arccsc","arcsinh","arccosh","arctanh",
    "arccoth","arccsch","arcsech","expand","factor","factors","coeffs","gcd",
    "lcm","rem","quo","plot","plot3d","\""->"%","`"->"\"","resultant",
    "collect", "sqrfree","bernoulli","cyclotomic","euler","fibonacci","numer",

    "denom","product","sum","dsolve","Ci","Chi","Li","Si","limit","series",
    "solve","root","eliminate","EigenVals","isprime","ithprime","factorset",
    "divisors","iquo","irem","igcd","ilcm","Gamma","GAMMA","Ai","Bi","Psi",
    "map","seq","simplify","subs","fsolve","numpart","stirling1","stirling2",
    "BesselI","BesselJ","BesselK","BesselY","Beta","coeff","compoly",
    "fortran","latex","RETURN","taylor","frac","whattype","Zeta","substring",
    "member","log","FresnelC","FresnelS","ihermite","lprint"};

LaplaceTransformDictionary={"LaplaceTransform"};

DescriptiveStatisticsDictionary={"Mean","CoefficientOfVariation",
    "GeometricMean","HarmonicMean","Kurtosis","MeanDeviation","Median","Mode",

    "RootMeanSquare","SampleRange","Skewness","StandardDeviationMLE",
    "VarianceMLE"};

DiscreteDistributionsDictionary={"BinomialDistribution",
    "HypergeometricDistribution","NegativeBinomialDistribution",
    "PoissonDistribution","ChiSquareDistribution"};

ContinuousDistributionsDictionary={"BetaDistribution","CauchyDistribution",
    "FRatioDistribution","GammaDistribution","LaplaceDistribution",
    "LogisticDistribution","LogNormalDistribution","NormalDistribution",
    "StudentTDistribution","UniformDistribution","WeibullDistribution"};

MultiDescriptiveStatisticsDictionary={"CovarianceMLE","Correlation"};

PackageDictionary={LaplaceTransformDictionary,DescriptiveStatisticsDictionary,

    DiscreteDistributionsDictionary,ContinuousDistributionsDictionary,
    MultiDescriptiveStatisticsDictionary};

BadFunctionalArguments={"kurtosis[","coefficientofvariation[","skewness["};

FirstRule ={"[["->"[[","]]"->"]]","["->"{","]"->"}"};

SecondRule =
   {"sin("->"Sin[","cos("->"Cos[","tan("->"Tan[","diff("->"D[","evalf("->"N[",

    "evalhf("->"N[", "int("->"Integrate[","abs("->"Abs[","argument("->"Arg[",
    "binomial("->"Binomial[","ceil("->"Ceiling[","conjugate("->"Conjugate[",
    "erf("->"Erf[","erfc("->"Erfc[","exp("->"Exp[","factorial("->"Factorial[",

    "floor("->"Floor[","ln("->"Log[","max("->"Max[","min("->"Min[",
    "round("->"Round[","signum("->"Sign[","sqrt("->"Sqrt[",
    "trunc("->"IntegerPart[","cot("->"Cot[","sec("->"Sec[","csc("->"Csc[",
    "sinh("->"Sinh[","cosh("->"Cosh[","tanh("->"Tanh[","sech("->"Sech[",
    "csch("->"Csch[","coth("->"Coth[","arcsin("->"ArcSin[",
    "arccos("->"ArcCos[","arctan("->"ArcTan[","arccot("->"ArcCot[",
    "arcsec("->"ArcSec[","arccsc("->"ArcCsc[","arcsinh("->"ArcSinh[",
    "arccosh("->"ArcCosh[","arctanh("->"ArcTanh[","arccoth("->"ArcCoth[",
    "arccsch("->"ArcCsch[","arcsech("->"ArcSech[","expand("->"Expand[",
    "factor("->"Factor[","factors("->"FactorList[",
    "coeffs("->"CoefficientList[","gcd("->"PolynomialGCD[",
    "lcm("->"PolynomialLCM[","rem("->"PolynomialRemainder[",
    "quo("->"PolynomialQuotient[","plot("->"Plot[","plot3d("->"Plot3DHOL[",
    "\""->"%","`"->"\"","resultant("->"Resultant[","collect("->"Collect[", 
    "sqrfree("->"FactorSquareFree[","bernoulli("->"BernoulliB[",
    "cyclotomic("->"Cyclotomic[","euler("->"EulerE[",
    "fibonacci("->"Fibonacci[","numer("->"Numerator[",
    "denom("->"Denominator[","product("->"Product[","sum("->"Sum[",
    "dsolve("->"DSolve[","Ci("->"CosIntegral[","Chi("->"CoshIntegral[",
    "Li("->"LogIntegral[","Si("->"SinIntegral[","limit("->"Limit[",
    "series("->"Series[","solve("->"Solve[","root("->"Root[",
    "eliminate("->"Eliminate[","EigenVals("->"Eignevalues[",
    "isprime("->"PrimeQ[","ithprime("->"Prime[",
    "factorset("->"FactorInteger[","divisors("->"Divisors[",
    "iquo("->"Quotient[","irem("->"Mod[","igcd("->"GCD[","ilcm("->"LCM[",
    "Gamma("->"EulerGamma[","GAMMA("->"Gamma[","AiryAi("->"AiryAi[",
    "AiryBi("->"AiryBi[","Psi("->"PolyGamma[","map("->"Map[","seq("->"Table[",

    "simplify("->"Simplify[","subs("->"RepeatedReplace[","fsolve("->"NSolve[",

    "numpart("->"Partitions[","stirling1("->"StirlingS1[",
    "stirling2("->"StirlingS2[","BesselI("->"BesselI[","BesselJ("->"BesselJ[",

    "BesselK("->"BesselK[","BesselY("->"BesselY[","Beta("->"Beta[",
    "coeff("->"Coefficient[","compoly("->"Decompose[",
    "fortran("->"FortranForm[","latex("->"TexForm[","RETURN("->"Return[",
    "taylor("->"Series[","frac("->"FractionalPart[","whattype("->"Head[",
    "Zeta("->"Zeta[","substring("->"StringTake[","member("->"MemberQ[",
    "laplace("->"LaplaceTransform[","log("->"Log[","log["->"Log[",
    "FresnelC("->"FresnelC[","FresnelS("->"FresnelS[",
    "ihermite("->"HermiteNormalForm[","lprint("->"InputForm["};

StatisticsFunctions={"mean("->"Mean[",
    "coefficientofvariation("->"CoefficientOfVariation[",
    "covariance("->"CovarianceMLE[","geometricmean("->"GeometricMean[",
    "harmonicmean("->"HarmonicMean[","kurtosis("->"Kurtosis[",
    "linearcorrelation("->"Correlation[","meandeviation("->"MeanDeviation[",
    "median("->"Median[","mode("->"Mode[","quadraticmean("->"RootMeanSquare[",

    "range("->"SampleRange[","skewness("->"Skewness[",
    "standarddeviation("->"StandardDeviationMLE[",
    "variance("->"VarianceMLE["};

StatisticalDistributions={"binomiald("->"BinomialDistribution[",
    "hypergeometric("->"HypergeometricDistribution[",
    "negativebinomial("->"NegativeBinomialDistribution[",
    "poisson("->"PoissonDistribution[","chisquare("->"ChiSquareDistribution[",

    "beta("->"BetaDistribution[","cauchy("->"CauchyDistribution[",
    "fratio("->"FRatioDistribution[","gamma("->"GammaDistribution[",
    "laplaced("->"LaplaceDistribution[","logistic("->"LogisticDistribution[",
    "lognormal("->"LogNormalDistribution[","normald("->"NormalDistribution[",
    "studentst("->"StudentTDistribution[","uniform("->"UniformDistribution[",
    "weibull("->"WeibullDistribution["};

LimitRules={"="->"->","right"->"Direction->-1","left"->"Direction->1"};

ThirdRule={"="->"==",":="->"=","HOL["->"["};

ColorRule={"aquamarine"->"Aquamarine","black"->"Black","blue"->"Blue",
    "navy"->"Navy","coral"->"Coral","cyan"->"Cyan","brown"->"Brown",
    "gold"->"Gold","green"->"Green","grey"->"Grey","gray"->"Gray",
    "khaki"->"Khaki","magenta"->"Magenta","maroon"->"Maroon",
    "orange"->"Orange","pink"->"Pink","plum"->"Plum","red"->"Red",
    "sienna"->"Sienna","tan"->"Tan","turquoise"->"Turquoise",
    "violet"->"Violet","wheat"->"Wheat","white"->"White","yellow"->"Yellow"};

PlotOptionsRule={"axes=none"->"Axes->True","axes=boxed"->"Frame->True",
    "axes=frame"->"Axes->True","axes=normal"->"Axes->True",
    "scaling=constrained"->"AspectRatio->Automatic","color="->"PlotStyle->",
    "labels="->"AxesLabel->","title="->"PlotLabel->"};

travdata={{0,"[",1},{0,"]",-1},{1,",",0}};
ubdata={{0,"[",1},{1,"]",-1},{1,",",0}};
fbdata={{0,"[",1},{0,"]",-1},{0,"(",1},{1,")",-1}};
gidata={{0,"[",1},{1,"]",-1}};

Clear[Traversal]
Traversal[data_,match_,terminate_,openclose_]:=
  Module[{clist,locs,i,j,k,counter,ending,locslist,len},
		locs=StringPosition[data,match];
		len=StringLength[data];
		clist=Characters[data];
		locslist={};
		For[k=1,k<=Length[locs],k++,
			i=locs[[k,1]];
			counter=0;
			ending=0;
			While[ending==0,
	       While[LetterQ[clist[[i]]] || DigitQ[clist[[i]]],
          If[i==len,Break[],i++]];
				If[i==len,ending=i,
					j=1;
					While[openclose[[j,2]]!=clist[[i]],
						If[j==Length[openclose],
							j++;
							Break[],j++]];
					If[j==Length[openclose]+1,counter+=0,
						Switch[openclose[[j,1]],
							0,counter+=openclose[[j,3]],
							_,If[counter==terminate,ending=i,counter+=openclose[[j,3]]]]]];
					i++;];
					
			AppendTo[locslist,ending]];
		Return[locslist];
		];


Clear[Rebuild]
Rebuild[argslist_]:=Module[{newstring,i},
		newstring=argslist[[1]]<>"[";
		For[i=2,i<Length[argslist],i++,
			newstring=newstring<>argslist[[i]]<>","];
		newstring=newstring<>Last[argslist]<>"]";
		Return[newstring]
	];


Clear[SwapArgs]
SwapArgs[data_,pos1_,pos2_]:=Module[{newargs},
	newargs=ReplacePart[data,data[[pos2]],pos1];
		newargs=ReplacePart[newargs,data[[pos1]],pos2];
		Return[newargs]
	];
		

Clear[IsolateExpression]
	IsolateExpression[data_,match_,num_]:=Module[{start,end,i,clist,counter},
		start=StringPosition[data,match][[num,1]];
		clist=Characters[data];
		i=start;
		end=0;
		counter=0;
		While[end==0,
			While[LetterQ[clist[[i]]] || DigitQ[clist[[i]]],i++];
			Switch[clist[[i]],
				"[",counter++,
				"]",If[counter==1,end=i,counter--]];
			i++;];
		Return[{start,end}]
	];

Clear[IsolateArguments]
	IsolateArguments[data_]:=
  Module[{start,end,i,clist,counter,arglist,tempstring,j,len},
		start=First[StringPosition[data,"["]][[1]]+1;
		len=StringLength[data];
		i=start;
		clist=Characters[data];
		arglist={StringTake[data,start-2]};
		While[i<len,
			counter=0;
			end=0;
			j=i;
		While[end==0,
			While[LetterQ[clist[[i]]] || DigitQ[clist[[i]]]&& i<len,i++];
			Switch[clist[[i]],
				"[",counter++,
				"]",If[i==StringLength[data],end=i,counter--],
				"{",counter++,
				"}",counter--,
				",",If[counter==0,end=i]
			];
			i++;
			];
		tempstring=StringTake[data,{j,end-1}];
		AppendTo[arglist,tempstring];
			];
		Return[arglist]
	];

Clear[FixExtract]
	FixExtract[data_]:=
  Module[{blocs,i,flag,pos,replist,endlist,newstring,replist2},
		blocs=StringPosition[data,"["];
		replist={};
     For[i=1,i<=Length[blocs],i++,
			If[blocs[[i,1]]!=1,
			flag=StringTake[data,{blocs[[i,1]]-1}];
			If[DigitQ[flag] || LetterQ[flag],
          AppendTo[replist,{blocs[[i,1]],blocs[[i,1]]}]]]];
		newstring=StringReplacePart[data,"[[",replist];
		endlist=Traversal[newstring,"[[",2,gidata];
		replist2={};
		For[i=1,i<=Length[endlist],i++,
					AppendTo[replist2,{endlist[[i]],endlist[[i]]}]];
		newstring=StringReplacePart[newstring,"]]",replist2];
		Return[newstring]
	];

Clear[FixLeftBrackets]
FixLeftBrackets[data_]:=Module[{locs,clist,i,spot,tempstring},
		tempstring=data;
		locs=StringPosition[data,"("];
		clist=Characters[data];
		For[i=1,i<=Length[locs],i++,
			spot= locs[[i,1]]-1;
			If[spot!=0,
        If[LetterQ[clist[[spot]]] || DigitQ[clist[[spot]]],
          tempstring=StringReplacePart[tempstring,"[",{spot+1,spot+1}]]]];
		Return[tempstring]
	];

Clear[FixRightBrackets]
FixRightBrackets[data_]:=Module[{tempstring,newstring,locs,test,i},
		tempstring=data;
		locs=Sort[Select[Traversal[tempstring,"[",1,fbdata],Positive]];
		If[Length[locs]>0,
		test=Last[locs];
		If[StringTake[tempstring,{test}]!=")",locs=Delete[locs,-1]]];
		For[i=1,i<=Length[locs],i++,
			tempstring=StringReplacePart[tempstring,"]",{locs[[i]],locs[[i]]}]
		];
		Return[tempstring]
	];
		
Clear[GetVariables]
GetVariables[data_]:=Module[{ending,clist,len,i,prob,tempstring},
		clist=Characters[data];
		len=Length[clist];
		ending=0;
		i=len;
		While[ending==0,
		  While[DigitQ[clist[[i]]] || LetterQ[clist[[i]]],If[i==1,Break[],i--]];
		If[i==1,ending=1,
			Switch[clist[[i]],
				",",i--,
				")",i--,
				"(",i--,
				"_",i--,
				" ",i--,
				_,ending=i]];
			];
		If[ending==1,ending=0];
		tempstring=StringTake[data,{ending+1,len}];
    tempstring=StringReplace[tempstring,{"("->"{",")"->"}"}];
		Return[{tempstring,ending+1}]
	];	

Clear[FixUserDefinedFunctions]
FixUserDefinedFunctions[data_]:=
  Module[{loc,place,varstring,rulestring,addin,returnstring},
		place=StringPosition[data,"->"];
		If[Length[place]==0,Return[data],
		loc=place[[1,1]];
		varstring=GetVariables[StringTake[data,loc-1]];
		rulestring=StringTake[data,{loc+2,StringLength[data]}];
		addin="Function["<>First[varstring]<>","<>rulestring<>"]";
	   returnstring=
        StringReplacePart[data,addin,{Last[varstring],StringLength[data]}];
		Return[returnstring]]
	];

Clear[FixDots]
FixDots[data_,num_]:=
  Module[{endpoints,tempstring,arglist,bounds,newarglist,addin,newstring},
		endpoints=IsolateExpression[data,"StringTake",num];
		tempstring=StringTake[data,endpoints];
		arglist=IsolateArguments[tempstring];
		tempstring=data;
		bounds=arglist[[3]];
		bounds=StringReplace[bounds,".."->","];
		bounds="{"<>bounds<>"}";
		newarglist=Drop[arglist,-1];
		AppendTo[newarglist,bounds];
		newstring=StringReplacePart[tempstring,Rebuild[newarglist],endpoints];
		Return[newstring]
	];

Clear[FixParametricPlot]
	FixParametricPlot[data_,num_]:=
  Module[{arglist,newarglist,endpoints,newstring,tempstring1,tempstring2,
      tempstring3,ep},
	endpoints=IsolateExpression[data,"Plot",num];
		tempstring1=StringTake[data,endpoints];
		arglist=IsolateArguments[tempstring1];
		If[StringMatchQ[arglist[[2]],"*..*"],
			arglist=ReplacePart[arglist,"ParametricPlot",1];
			ep=FindName[arglist[[2]]];
			tempstring2=StringTake[arglist[[2]],ep];
			tempstring2=
        StringReplacePart[tempstring2,
          "}",{StringLength[tempstring2],StringLength[tempstring2]}];
			tempstring3=StringTake[arglist[[2]],{ep+1,StringLength[arglist[[2]]]-1}];
		newarglist=ReplacePart[arglist,tempstring2,2];
			newarglist=Insert[newarglist,tempstring3,3];
			newstring=StringReplacePart[data,Rebuild[newarglist],endpoints];
			Return[newstring]];
		Return[data]
	];

Clear[FindName]
FindName[data_]:=Module[{i,clist,pos},
		pos=FindLowerBound[data];
		i=pos;
		clist=Characters[data];
		While[clist[[i]]!=",",i--];
		Return[i]];

Clear[FindLowerBound]
FindLowerBound[data_]:=Module[{i,clist,pos},
		pos=StringPosition[data,".."][[1,1]];
		i=pos;
		clist=Characters[data];
		While[clist[[i]]!="=",i--];
		Return[i]];

Clear[FixRange]
	FixRange[data_]:=
  Module[{flagpos,namepos,name,lbpos,lb,ubpos,ub,newstring,addin,tempstring},
		tempstring=data;
	 If[StringMatchQ[data,"*Plot*"],tempstring=FixPlotRange[data]];
		flagpos=StringPosition[tempstring,".."][[1,1]];
		namepos=FindName[tempstring];
    lbpos=FindLowerBound[tempstring];
		name = StringTake[tempstring,{namepos+1,lbpos-1}];
    lb=StringTake[tempstring,{lbpos+1,flagpos-1}];
		ubpos=Traversal[tempstring,"..",0,ubdata][[1]];
		ub=StringTake[tempstring,{flagpos+2,ubpos-1}];
     addin="{"<>name<>","<>lb<>","<>ub<>"}";
    newstring=
      StringInsert[StringDrop[tempstring,{namepos+1,ubpos-1}],addin,
        namepos+1];
    Return[newstring]
		];		

Clear[PlotRangeQ]
PlotRangeQ[data_]:=Module[{pos1,pos2,tempstring,newstring},
		tempstring=data;
		If[!StringMatchQ[tempstring,"*Plot3D*"],
		pos1=Traversal[tempstring,"Plot",1,travdata][[1]];
	  newstring=StringTake[data,{pos1+1,StringLength[data]}];
		pos2=Traversal[newstring,"..",0,ubdata][[1]];
		newstring=StringTake[newstring,{pos2+1,StringLength[newstring]}];
		If[Length[StringPosition[newstring,".."]]>0 , Return[True],Return[False]],
			Return[False]]
	];


Clear[FixPlotRange]
FixPlotRange[data_]:=Module[{tempstring},
		tempstring=data;
		If[PlotRangeQ[tempstring],tempstring=FPR[tempstring]];
		Return[tempstring]
	];

Clear[FPR]
	FPR[data_]:=
  Module[{tempstring,newstring,pos1,pos2,lbpos,lb,ubpos,ub,flagpos},
		pos1=Traversal[data,"Plot",1,travdata][[1]];
	  newstring=StringTake[data,{pos1+1,StringLength[data]}];
		pos2=Traversal[newstring,"..",0,ubdata][[1]];
		newstring=StringTake[newstring,{pos2+1,StringLength[newstring]}];
		flagpos=StringPosition[newstring,".."][[1,1]];
		lbpos=FindLowerBound[newstring];
		ubpos=Traversal[newstring,"..",0,ubdata][[1]];
	  lb=StringTake[newstring,{lbpos+1,flagpos-1}];
		ub=StringTake[newstring,{flagpos+2,ubpos-1}];
		newstring="PlotRange->{"<>lb<>","<>ub<>"}";
		tempstring=
      StringInsert[StringDrop[data,{pos1+pos2+1,pos1+pos2+ubpos-1}],newstring,

        pos1+pos2+1];
		Return[tempstring]
	];

Clear[FS]
	FS[data_]:=Module[{newstring,arglist,k,tempstring},
    tempstring=StringTake[data,IsolateExpression[data,"RepeatedReplace",1]];
		arglist=IsolateArguments[tempstring];
		tempstring="{";
		For[k=2,k<Length[arglist],k++,
			tempstring=tempstring<>arglist[[k]]<>","];
		tempstring=StringDrop[tempstring,{StringLength[tempstring]}];
		tempstring=tempstring<>"}";
		tempstring=StringReplace[tempstring,"="->"->"];
	  newstring="ReplaceRepeated"<>"["<>Last[arglist]<>","<>tempstring<>"]";
		Return[newstring]
	];

Clear[FixSubstitution]
FixSubstitution[data_]:=Module[{endpoints,tempstring,newstring},
		endpoints=IsolateExpression[data,"RepeatedReplace",1];
		tempstring=FS[data];
		newstring=
      StringReplacePart[data,tempstring,{endpoints[[1]],endpoints[[2]]}];
		Return[newstring]
	];

Clear[FixMember]
	FixMember[data_,num_]:=
  Module[{tempstring,newstring,addin,endpoints,arglist},
		endpoints=IsolateExpression[data,"MemberQ",num];
		tempstring=StringTake[data,endpoints];
		arglist=IsolateArguments[tempstring];
		arglist=SwapArgs[arglist,2,3];
		addin=Rebuild[arglist];
		newstring=StringReplacePart[data,addin,endpoints];
		Return[newstring]
	];

Clear[FD]
FD[data_]:=Module[{i,newstring,arglist,loc,tempstring,leftparts,rightparts},
		leftparts={};
		rightparts={};
		tempstring="";
		arglist=IsolateArguments[data];
		For[i=3,i<=Length[arglist],i++,
			newstring=StringReplace[arglist[[i]],{"{"->"","}"->""}];
			arglist=ReplacePart[arglist,newstring,i];];
		newstring=Rebuild[arglist];
		arglist=IsolateArguments[newstring];
		For[i=3,i<=Length[arglist],i++,
			loc=StringPosition[arglist[[i]],"$"];
			If[Length[loc]==0,
				AppendTo[leftparts,arglist[[i]]];
				AppendTo[rightparts,"1"],
				AppendTo[leftparts,StringTake[arglist[[i]],{1,loc[[1,1]]-1}]];
				AppendTo[rightparts,
          StringTake[
            arglist[[i]],{loc[[1,1]]+1,StringLength[arglist[[i]]]}]]];];
		For[i=1,i<=Length[leftparts],i++,
			If[rightparts[[i]]=="1",
				tempstring=tempstring<>leftparts[[i]]<>",",
			tempstring=
          tempstring<>"{"<>leftparts[[i]]<>","<>rightparts[[i]]<>"}"<>","]];
		tempstring=StringDrop[tempstring,-1];
		newlist={arglist[[1]],arglist[[2]],tempstring};
		newstring=Rebuild[newlist];
		Return[newstring]
	];
		
Clear[FixDerivative]
FixDerivative[data_]:=Module[{i,locs,newstring,returnstring,endpoints},
		returnstring=data;
		locs=StringPosition[returnstring,"D["];
		For[i=1,i<=Length[locs],i++,
			endpoints=IsolateExpression[returnstring,"D[",i];
      newstring=StringTake[returnstring,endpoints];
			newstring=FD[newstring];
			returnstring=StringReplacePart[returnstring,newstring,endpoints]];
		Return[returnstring]
	];

Clear[FixDSolve]
FixDSolve[data_]:=Module[{locs,i,endpoints,returnstring,newstring,arglist},
		returnstring=data;
		locs=StringPosition[returnstring,"DSolve"];
		For[i=1,i<=Length[locs],i++,
			endpoints=IsolateExpression[returnstring,"DSolve",i];
			newstring=StringTake[returnstring,endpoints];
			arglist=IsolateArguments[newstring];
			newstring=
        Rebuild[{arglist[[1]],arglist[[2]],arglist[[3]],"Insert I.V Here"}];
			returnstring=StringReplacePart[returnstring,newstring,endpoints]];
		Return[returnstring]
	];
			
Clear[FixLog]
FixLog[data_]:=Module[{locs,tempstring},
		tempstring=data;
		locs=IsolateExpression[tempstring,"Log[[",1];
		tempstring=StringReplacePart[tempstring,",",{Last[locs]-1,Last[locs]+1}];
		tempstring=StringDrop[tempstring,{First[locs]+3}];
		Return[tempstring]
	];
		
Clear[FixHypergeometricDistribution]
FixHypergeometricDistribution[data_]:=
  Module[{locs,i,arglist,tempstring,tempstring2,endpoints},
    locs=StringPosition[data,"HypergeometricDistribution"];
		tempstring=data;
		For[i=1,i<=Length[locs],i++,
			endpoints=IsolateExpression[tempstring,"HypergeometricDistribution",i];
			tempstring2=StringTake[tempstring,endpoints];
			arglist=IsolateArguments[tempstring2];
			arglist=SwapArgs[arglist,4,3];
			arglist=SwapArgs[arglist,2,3];
			tempstring2=Rebuild[arglist];
			tempstring=StringReplacePart[tempstring,tempstring2,endpoints];
			];
		Return[tempstring]
	];
		
Clear[FixBadArguments]
FixBadArguments[data_]:=
  Module[{endpoints,i,j,tempstring1,tempstring2,match,locs},
		tempstring1=data;
		For[i=1,i<=Length[BadFunctionalArguments],i++,
			match=BadFunctionalArguments[[i]];
			locs=StringPosition[tempstring1,match];
			For[j=1,j<=Length[locs],j++,
				endpoints=IsolateExpression[tempstring1,match,j];
				tempstring2=StringTake[tempstring1,endpoints];
				tempstring2=
          StringTake[tempstring2,StringPosition[tempstring2,"["][[1,1]]-1];
				tempstring1=StringReplacePart[tempstring1,tempstring2,endpoints];
				];
			];
		Return[tempstring1]
	];

Clear[FixLimit]
FixLimit[data_]:=Module[{arglist,tempstring,endpoints,i,locs,returnstring},
		locs=StringPosition[data,"Limit["];
		returnstring=data;
		For[i=1,i<=Length[locs],i++,
			endpoints=IsolateExpression[returnstring,"Limit",i];
			tempstring=StringTake[returnstring,endpoints];
			tempstring=StringReplace[tempstring,LimitRules];
			returnstring=StringReplacePart[returnstring,tempstring,endpoints];
			];
		Return[returnstring]
	];

Clear[gp]
GetParameters[data_]:=Module[{loc,i,tempstring,paramlist},
		tempstring=StringTake[data,IsolateExpression[data,"proc",1]];
    templist=IsolateArguments[tempstring];
		paramlist={};
		For[i=2,i<=Length[templist],i++,
			tempstring=templist[[i]];
			loc=StringPosition[tempstring,"::"];
			If[Length[loc]!=0,
				AppendTo[paramlist,StringTake[tempstring,loc[[1,1]]-1]],
				AppendTo[paramlist,tempstring]];
			];
		Return[paramlist]
	];

Clear[GetLocalVariables]
GetLocalVariables[data_]:=
  Module[{varlist,templist,tempstring,locs,tlocs,i,j},
		locs=StringPosition[data,"local"];
		varlist={};
		For[i=1,i<=Length[locs],i++,
			tempstring=StringDrop[data,locs[[i,2]]+1];
			tlocs=StringPosition[tempstring,";"][[1,1]];
			tempstring=StringTake[tempstring,tlocs-1];
			templist=IsolateArguments["flag["<>tempstring<>"]"];
			For[j=2,j<=Length[templist],j++,
				AppendTo[varlist,{templist[[j]],locs[[i,1]],tlocs}]];
			];
		Return[varlist]
	];

Clear[BuildParameterString]
BuildParameterString[paramlist_]:=Module[{i,paramstring},
		paramstring="";
		For[i=1,i<Length[paramlist],i++,
			paramstring=paramstring<>paramlist[[i]]<>"_,"];
		If[Length[paramlist]!=0,paramstring=paramstring<>Last[paramlist]<>"_"];
		Return[paramstring]
	];

Clear[BuildVariableString]
 BuildVariableString[varlist_]:=Module[{varstring,i},
			varstring="{";
		For[i=1,i<Length[varlist],i++,
			varstring=varstring<>varlist[[i,1]]<>","];
		If[Length[varlist]!=0,varstring=varstring<>Last[varlist][[1]]];
		varstring=varstring<>"}";
		Return[varstring]
	];

Clear[BuildBodyString]
BuildBodyString[data_,varlist_]:=Module[{i,body,loc,droplist},
		loc=First[Traversal[data,"proc",1,{{0,"[",1},{1,"]",-1}}]];
		droplist={};
		For[i=1,i<=Length[varlist],i++,
			AppendTo[droplist,{varlist[[i,2]],varlist[[i,2]]+varlist[[i,3]]+6}]];
		body=StringReplacePart[data,"",Union[droplist]];
		body=StringDrop[body,loc];
		body=StringDrop[body,-4];
		i=1;
		While[StringTake[body,{-i}]===" " || StringTake[body,{-i}]==="\n",i++];
		If[StringTake[body,{-i}]===";", body=StringDrop[body,{-i}]];
		Return[body]
	];

Clear[FixProc]
	FixProc[data_]:=
  Module[{funcname,paramstring,loc,tempstring,i,headerstring,varlist,
      varstring,droplist,body},
		loc=StringPosition[data,"proc"];
		If[(loc[[1,1]]-2)>=0,tempstring=StringTake[data,loc[[1,1]]-2],
			tempstring="SetFunctionName"];
		funcname=GetVariables[tempstring][[1]];
		paramstring=BuildParameterString[GetParameters[data]];
		varlist=GetLocalVariables[data];
		varstring=BuildVariableString[varlist];
		body=BuildBodyString[data,varlist];
	  headerstring=
      funcname<>"["<>paramstring<>"]:=Module["<>varstring<>","<>body<>"];";
		Return[headerstring]
	];

Clear[MapleToMathematica]
MapleToMathematica[expression_]:=Module[{newstring,i},
		newstring =expression;
		newstring= FixBadArguments[newstring];
		newstring= FixExtract[newstring];
		newstring =StringReplace[newstring,FirstRule];
		newstring =StringReplace[newstring,SecondRule];
		newstring =StringReplace[newstring,StatisticsFunctions];
		newstring =StringReplace[newstring,StatisticalDistributions];
		While[StringMatchQ[newstring,"*Log[[*"],newstring=FixLog[newstring]];
		newstring = FixLeftBrackets[newstring];
		newstring = FixRightBrackets[newstring];
		newstring = FixUserDefinedFunctions[newstring];
		newstring =StringReplace[newstring,ColorRule];
    For[i=1,i<=Length[StringPosition[newstring,"StringTake"]],i++,
      newstring=FixDots[newstring,i]];
		If[StringMatchQ[newstring,"*Plot*"],
	     newstring=FixParametricPlot[newstring,1]];
	  While[StringMatchQ[newstring,"*..*"],
				newstring = FixRange[newstring]];
		While[StringMatchQ[newstring,"*RepeatedReplace*"],
				newstring = FixSubstitution[newstring]];
	  For[i=1,i<=Length[StringPosition[newstring,"MemberQ"]],i++,
      newstring=FixMember[newstring,i]];
		newstring=FixDerivative[newstring];
		newstring=FixDSolve[newstring];
		newstring=FixHypergeometricDistribution[newstring];
	  newstring = StringReplace[newstring,PlotOptionsRule];
		newstring=FixLimit[newstring];
		newstring = StringReplace[newstring,ThirdRule];
		If[StringMatchQ[newstring,"*proc[*"],newstring=FixProc[newstring]]; 
		Return[newstring] 
		];

Clear[GetStyles]
GetStyles[inname_]:=Module[{stylelist,returnlist,styletype,othertype},
		returnlist={};
		stylelist=
      ReadList[inname,Record,
        RecordSeparators->{{"PSTYLE","PSTYLE"},{"}{","}\n{"}}];
		For[i=1,i<=Length[stylelist],i++,
			If[StringTake[stylelist[[i]],3]==" \"\"",
				styletype=GetFormatNumber[StringDrop[stylelist[[i]],1],1];
				othertype=GetFormatNumber[StringDrop[stylelist[[i]],5],1];
				AppendTo[returnlist,{styletype,othertype}]]];
		Return[returnlist]
	];
	
	
Clear[GetFormatNumber]
GetFormatNumber[data_,num_]:=Module[{i,clist,formatstring,formatnumber,loc},
		Off[ToExpression::sntxi];
		clist=Characters[data];
		formatstring="";
		i=StringPosition[data," "][[num,1]]+1;
		While[clist[[i]]!=" ",
			formatstring=formatstring<>clist[[i]];
			i++;];
		formatnumber=ToExpression[formatstring];
		On[ToExpression::sntxi];
		Return[formatnumber]
	];
	
Clear[GetContent]
GetContent[data_]:=
  Module[{tempstring1,tempstring2,tempstring3,i,k,locs,poslist,lenlist,
      locslist,size},
		size=Length[StringPosition[data,"\\n"]];
	  tempstring1=StringReplace[data,{"\n"->"","\r"->"","\\+"->""}];
		locslist={};
		lenlist={};
    locs=StringPosition[tempstring1,"TEXT"];
	  For[i=1,i<=Length[locs],i++,
			tempstring2=StringDrop[tempstring1,locs[[i,1]]];
			If[IntegerQ[GetFormatNumber[tempstring2,3]],
        len=GetFormatNumber[tempstring2,3],
        len=GetFormatNumber[tempstring2,2]];
			AppendTo[lenlist,len]];
		poslist=StringPosition[tempstring1,"\""];
		k=1;
		For[i=1,i<=Length[locs],i++,
			While[poslist[[k,1]]<locs[[i,1]],k++];
			AppendTo[locslist,poslist[[k,1]]]];
		tempstring3="";
		For[i=1,i<=Length[locslist],i++,
			tempstring3=
        tempstring3<>
          StringTake[
            tempstring1,{locslist[[i]]+1,locslist[[i]]+lenlist[[i]]+size}]];
		Return[tempstring3]
				];
				
Clear[Breakdown]
Breakdown[datalist_]:=
  Module[{paralist,returnlist,tempstring,tempstring2,i,j,locs,dellist},
		returnlist=datalist;
		dellist={};
	For[j=1,j<=Length[returnlist],j++,
						If[StringMatchQ[returnlist[[j]],"*XPPMATH*"] || 
          StringMatchQ[returnlist[[j]],"*INLPLOT*"],
							AppendTo[dellist,{j}]]];
	returnlist=Delete[returnlist,dellist];
	Return[returnlist]
	];
		

Clear[PreprocessFile]
PreprocessFile[inname_]:=
  Module[{commandlist,tempstring,j,formatnumber,inputtype,content,returnlist},

    
		returnlist={};
		commandlist=
      ReadList[inname,Record,
        RecordSeparators->{{"PARA","PARA"},{"}}","}\n"}}];
		commandlist=Breakdown[commandlist];
		For[j=1,j<=Length[commandlist],j++,
				tempstring=commandlist[[j]];
	    	formatnumber=GetFormatNumber[tempstring,1];
	    	If[StringMatchQ[tempstring,"*{TEXT*"],inputtype=0,inputtype=1];
	    	content=GetContent[tempstring];
			  content=StringReplace[content,"\\n"->"\n"];
			  If[content!="",
			 AppendTo[returnlist,{inputtype,formatnumber,content}]];];
		Return[returnlist]
	];
	
Clear[StyleMap]
	StyleMap[type_,styles_]:=Module[{i,len},
		i=1;
		len=Length[styles];
		If[len>0,
		While[styles[[i,2]]!=type,
			If[i==len,
				i++;
				Break[],
				i++]]];
	Switch[i,
			len+1,Return[type],
			_,Return[styles[[i,1]]]]
	];
	
Clear[GetFormatList]
GetFormatList[data_,styles_]:=Module[{i,j,returnlist,templist,type},
		returnlist={};
		For[i=1,i<=Length[data],i++,
			templist=data[[i]];
			If[templist[[1]]==0,
				type=StyleMap[templist[[2]],styles];
				Switch[type,
					3,format="Section",
					4,format="Subsection",
					5,format="Subsubsection",
					18,format="Title",
					19,format="Subtitle",
					20,format="Subsubtitle",
					_,format="Text"],
				format="Input"];
			AppendTo[returnlist,format]];
		Return[returnlist]
	];
					
					
Clear[GetContentList]
GetContentList[data_]:=Module[{i,j,returnlist,contentlist,tempstring},
		returnlist={};
		For[i=1,i<=Length[data],i++,
				If[data[[i,1]]==0,
					AppendTo[returnlist,data[[i,3]]], 
        tempstring=MapleToMathematica[data[[i,3]]];
        If[!StringMatchQ[tempstring,"*Module*"],
          tempstring=StringReplace[tempstring,{";"->"",":"->";"}]];
				tempstring=StringReplace[tempstring,"\\"->""];
					AppendTo[returnlist,tempstring]]
					];
	 For[i=1,i<=Length[returnlist],i++,
		returnlist[[i]]=StringReplace[returnlist[[i]],{"\\+"->"","\\n"->"\n"}]];
		Return[returnlist]
	];
	
Clear[GetNeededPackages]
GetNeededPackages[contents_,formats_]:=Module[{i,j,returnlist},
		returnlist={};
		For[j=1,j<=Length[contents],j++,
					If[formats[[j]]=="Input",
						For[i=1,i<=Length[LaplaceTransformDictionary],i++,
							If[
            Length[StringPosition[contents[[j]],
                  LaplaceTransformDictionary[[i]]]]>0,
            AppendTo[returnlist,"<<Calculus`LaplaceTransform`"]]];
						For[i=1,i<=Length[DescriptiveStatisticsDictionary],i++,
							If[
            Length[StringPosition[contents[[j]],
                  DescriptiveStatisticsDictionary[[i]]]]>0,
            AppendTo[returnlist,"<<Statistics`DescriptiveStatistics`"];
            i=100000]];
						For[i=1,i<=Length[DiscreteDistributionsDictionary],i++,
							If[
            Length[StringPosition[contents[[j]],
                  DiscreteDistributionsDictionary[[i]]]]>0,
            AppendTo[returnlist,"<<Statistics`DiscreteDistributions"];
            i=100000]];
						For[i=1,i<=Length[ContinuousDistributionsDictionary],i++,
							If[
            Length[StringPosition[contents[[j]],
                  ContinuousDistributionsDictionary[[i]]]]>0 ,
            AppendTo[returnlist,"<<Statistics`ContinuousDistributions`"];
            i=100000]];
							For[i=1,i<=Length[MultiDescriptiveStatisticsDictionary],i++,
							If[
            Length[StringPosition[contents[[j]],
                  MultiDescriptiveStatisticsDictionary[[i]]]]>0,
            AppendTo[returnlist,"<<Statistics`MultiDescriptiveStatistics`"];
            i=100000]];
						]];
		  returnlist=Union[returnlist];
			Return[returnlist]
		];
		
Clear[ConvertWorkSheet]
ConvertWorkSheet[inname_]:=
  Module[{packet,templist,i,returnlist,formatlist,contentlist,styles,
      loadlist},
		styles=GetStyles[inname];
	  returnlist={};
		packet=PreprocessFile[inname];
		formatlist=GetFormatList[packet,styles];
		contentlist=GetContentList[packet];
		loadlist=GetNeededPackages[contentlist,formatlist];
    For[i=1,i<=Length[loadlist],i++,
			AppendTo[returnlist,Cell[loadlist[[i]],"Input"]]];
		For[i=1,i<=Length[contentlist],i++,
			If[StringLength[contentlist[[i]]]!=0,
			AppendTo[returnlist,Cell[contentlist[[i]],formatlist[[i]]]]]];
		Return[returnlist]
	];
	  
Clear[GetFileName]
GetFileName[] :=
	Module[{nb, result},
		nb = NotebookCreate[Visible -> False,
		DefaultNewCellStyle -> "Text"];
	NotebookWrite[nb, ""];
	FrontEndExecute[{FrontEnd`FrontEndToken[nb,
			"FileNameDialog"]}];
	SelectionMove[nb, All, CellContents];
	result = NotebookRead[nb];
	NotebookClose[nb, Interactive -> False];
	ToExpression[result]
	];
	
Clear[EvaluateExpression]
EvaluateExpression[input_]:=
	ToExpression[MapleToMathematica[input]];
	
Clear[ConvertExpression]
ConvertExpression[input_]:=
	NotebookWrite[InputNotebook[], MapleToMathematica[input]];

End[]

EndPackage[]

