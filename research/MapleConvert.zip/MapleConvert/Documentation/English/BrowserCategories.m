BrowserCategory["Maple Converter", None,  
   {    
    Item["General Information", "MTrans.nb", CopyTag-> "GeneralInformation"],
    Item["Basic Operation and Examples", "MTrans.nb", CopyTag-> "BasicOperation"]   
   }]